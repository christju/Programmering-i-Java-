class HeiMeg {
  public static void main(String[] args) {
    System.out.println("Hei Christian!");
  }
}
