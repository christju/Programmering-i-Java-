/**
* HeiVerden.java -  "Programmering i Java", 4.utgave - 2009-07-01
* Vårt første program.
*/


class HeiVerden {
  public static void main(String[] args) {
    System.out.println("Hei verden!");
  }
}
